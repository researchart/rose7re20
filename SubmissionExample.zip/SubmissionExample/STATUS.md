We are applying to the Available badge, as the package is functional and 
accessible through the following doi: https://doi.org/10.5281/zenodo.2625706

We are also applying to the Rusable badge, as we have documented expected learning outcomes, 
and guidelines on how to apply the approach in an RE course in the file README.md
